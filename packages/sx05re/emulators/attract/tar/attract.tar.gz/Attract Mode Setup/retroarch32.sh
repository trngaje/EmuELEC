#!/usr/bin/env bash

/home/odroid/emulator/retroarch/retroarch32 "$@"
