#!/bin/bash

/home/odroid/overclock/OC_select.sh

