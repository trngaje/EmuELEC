#!/bin/bash
ee_console enable
/storage/runcommand/runcommand_setting.sh
ee_console disable
