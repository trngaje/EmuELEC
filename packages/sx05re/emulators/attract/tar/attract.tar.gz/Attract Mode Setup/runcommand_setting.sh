#!/bin/bash

/storage/runcommand/runcommand_setting.sh
