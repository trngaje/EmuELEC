#!/usr/bin/env bash

/usr/bin/retroarch "$@"
