#!/bin/bash

#sudo mount -t exfat /dev/sda1 /mnt

cd ~/util/commander
./DinguxCommander.sh

