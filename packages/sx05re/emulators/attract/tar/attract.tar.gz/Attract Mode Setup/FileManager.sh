#!/bin/bash

#sudo mount -t exfat /dev/sda1 /mnt

cd /home/odroid/util/commander
./DinguxCommander.sh

