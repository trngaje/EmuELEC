#!/bin/bash
clear

echo "======== DISK INFO =========="
echo ""

df -h

echo ""
echo " Exit after 5 seconds....."
sleep 5
clear