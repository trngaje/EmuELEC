#!/bin/bash
DISKINFO="======== DISK INFO ==========\n\n"
DISKINFO+=`df -h`
DISKINFO+="\n"
DISKINFO+="\n"
text_viewer -m "$DISKINFO" -t "Disk info" -f 24

