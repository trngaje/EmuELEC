#!/bin/bash

IPADDR="======== IP address ==========\n\n" 
IPADDR+=`ip addr show wlan0 | grep "inet\b" | awk '{print $2}' | cut -d/ -f1` 
text_viewer -m "$IPADDR" -t "IP address" -f 24
