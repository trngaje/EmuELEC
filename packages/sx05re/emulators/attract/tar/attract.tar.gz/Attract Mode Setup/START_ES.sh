#!/usr/bin/env bash

#cp /home/odroid/.start_es /home/odroid/autostart.sh
#sudo chmod 755 /home/odroid/autostart.sh

#sudo killall emulationstation
#sudo reboot

set_ee_setting ee_boot Emulationstation
reboot
