#!/bin/bash
sudo nmui

