#!/usr/bin/env bash

cd ~/util/textEditor/
./glutexto
