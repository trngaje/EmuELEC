#!/bin/bash
/home/odroid/util/splash/splash.sh

