#!/bin/bash
#LOADING_PATH=/home/odroid/runcommand
#ffplay $LOADING_PATH/loading.mp4 -autoexit -t 3 -loglevel quiet & > /dev/null 2>&1

clear

corename=`basename $CORE`

echo "=== $corename" >> $LOG_FILE

# SDL2 rotate init
export SDL2_OGS_VERTICAL=
