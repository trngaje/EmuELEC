#!/bin/bash

setterm -cursor off

SCRIPT_PATH=$(dirname $(realpath $0))
source "$SCRIPT_PATH/runcommand.cfg"
###############################################################################

# ARG
EMULATOR=$1
ROM=$2
ROM_TINY="${ROM##*/}"
ROM_FILENAME="${ROM_TINY%.*}"
ROM_PATH="/storage/roms/$EMULATOR"
ROM_PATH_REAL=`dirname "$ROM"`
OVERCLOCK_PATH="/storage/overclock"


# LOADING VIDEO
LOADING_PATH=/storage/runcommand

export EMULATOR
export ROM_FILENAME
export ROM_PATH
export ROM_PATH_REAL
export LOG_FILE
export CORE
################################################################################

# joy2key 프로세스 죽이기
function func_KillJoy2Key()
{
	JOY2KEY_PID=$(pgrep -f joy2key.py)
	kill "$JOY2KEY_PID"
	#killall "joy2key.py" > /dev/null 2>&1
}


# 에뮬레이터별 오버클럭 모드 cfg 불러오기
function func_LoadEmulatorOverClockMode()
{
	## EMULATOR OVERCLOCK CFG LOAD ###################################################
	if [ -f "$RUNCOMMAND_PATH/overclock/$EMULATOR.cfg" ] ; then
		OVERCLOCK_MODE=`cat "$RUNCOMMAND_PATH/overclock/$EMULATOR.cfg"`
	else
		OVERCLOCK_MODE="NORMAL"
	fi
	############################################################################
	
	echo "OVERCLOCK_MODE : $OVERCLOCK_MODE" >> $LOG_FILE

}

# 에뮬레이터별 코어 값 cfg 불러오기
function func_LoadEmulatorCfg()
{
	## EMULATOR CORE CFG LOAD ###################################################
	if [ -f "$RUNCOMMAND_PATH/cfg/$EMULATOR.cfg" ] ; then
		source "$RUNCOMMAND_PATH/cfg/$EMULATOR.cfg"
		echo "CFG LOAD : $RUNCOMMAND_PATH/cfg/$EMULATOR.cfg" >> $LOG_FILE
	else
		echo "CFG LOAD ERROR : $RUNCOMMAND_PATH/cfg/$EMULATOR.cfg" >> $LOG_FILE
		func_KillJoy2Key
		clear
		exit 0
	fi
	
	if [ ! -d "$RUNCOMMAND_PATH/defaultGameCore/$EMULATOR" ] ; then
		mkdir $RUNCOMMAND_PATH/defaultGameCore/$EMULATOR
	fi
	
	echo "DEFAULT CORE : $DEFAULT" >> $LOG_FILE
	#############################################################################

}

# 게임에 설정된 코어 읽어오기
function func_LoadGameCore()
{
	## EMULATOR CORE CFG LOAD ###################################################
	if [ -f "$RUNCOMMAND_PATH/defaultGameCore/$EMULATOR/$ROM_TINY.cfg" ] ; then
		GAME_DEFAULT=`cat "$RUNCOMMAND_PATH/defaultGameCore/$EMULATOR/$ROM_TINY.cfg"`
	else
		GAME_DEFAULT=""
	fi
	############################################################################
	
	echo "GAME_CORE : $GAME_DEFAULT" >> $LOG_FILE
	
}

# 에뮬레이터별 오버클럭 모드 선택 변경
function func_OverClockSelect()
{

	echo "" >> $LOG_FILE
	echo "=== func_OverClockSelect" >> $LOG_FILE
	
	dialog --clear --no-cancel   \
	--title "[ O V E R C L O C K - S E L E C T ]" \
	--menu "UP/DOWN A-BUTTON! \n\
	EMULATOR : $EMULATOR \n\
	CURRENT MODE : $OVERCLOCK_MODE " 25 100 60 \
	0 "PERFORMANCE" \
	1 "NORMAL" 2>$RUNCOMMAND_PATH/ocItem > /dev/tty0

	############################################ select menu #######################################################
	ocItem=`cat $RUNCOMMAND_PATH/ocItem` 

	if [ "$ocItem" == "0" ]; then
		echo "PERFORMANCE" > "$RUNCOMMAND_PATH/overclock/$EMULATOR.cfg"
	elif [ "$ocItem" == "1" ]; then
		echo "NORMAL" > "$RUNCOMMAND_PATH/overclock/$EMULATOR.cfg"
	fi

	echo "OVERCLOCK FILE : $RUNCOMMAND_PATH/overclock/$EMULATOR.cfg" >> $LOG_FILE
}



# 에뮬레이터 디폴트 코어 변경
function func_DefaultCoreSelect()
{
	echo "" >> $LOG_FILE
	echo "=== func_DefaultCoreSelect" >> $LOG_FILE
	
	OPTIONS=()
	for (( i = 0 ; i < ${#CORES[@]} ; i++ )) ; do
 		OPTIONS+=("$i"  "${CORES[$i]}")
	done
	OPTIONS+=("EXIT" "EXIT")
	#echo ${ZZZ[@]}

	dialog --clear --no-cancel   \
	--title "[ DEFAULT C O R E - S E L E C T ]" \
	--menu "UP/DOWN A-BUTTON! \n\
	EMULATOR : $EMULATOR \n\
	ROM : $ROM_TINY \n\
	DEFAULT CORE : $DEFAULT" 25 100 60 \
	"${OPTIONS[@]}" 2>$RUNCOMMAND_PATH/defaultitem > /dev/tty0

	############################################ select menu #######################################################
	defaultitem=`cat $RUNCOMMAND_PATH/defaultitem` 
	
	if [ "$defaultitem" != "EXIT" ]; then
		SEL_DEFAULT=${CORES[$defaultitem]}
	fi

	# cfg 파일에 저장
	if [ "$SEL_DEFAULT" != "" ]; then
		sed -i "1s/.*/DEFAULT=\"$SEL_DEFAULT\"/g" $RUNCOMMAND_PATH/cfg/$EMULATOR.cfg
	fi 
}

# 게임별 코어를 선택 변경
function func_GameCoreSelect()
{

	echo "" >> $LOG_FILE
	echo "=== func_GameCoreSelect" >> $LOG_FILE
	
	OPTIONS=()
	for (( i = 0 ; i < ${#CORES[@]} ; i++ )) ; do
 		OPTIONS+=("$i"  "${CORES[$i]}")
	done
	OPTIONS+=("EXIT" "EXIT")
	#echo ${ZZZ[@]}

	dialog --clear --no-cancel   \
	--title "[ G A M E - C O R E - S E L E C T ]" \
	--menu "UP/DOWN A-BUTTON! \n\
	EMULATOR : $EMULATOR \n\
	ROM : $ROM_TINY \n\
	GAME CORE : $DEFAULT" 25 100 60 \
	"${OPTIONS[@]}" 2>$RUNCOMMAND_PATH/gameitem > /dev/tty0

	############################################ select menu #######################################################
	gameitem=`cat $RUNCOMMAND_PATH/gameitem` 

	# make decsion 
	if [ "$gameitem" != "EXIT" ]; then
		GAME_DEFAULT=${CORES[$gameitem]}
	fi

	if [ "$GAME_DEFAULT" != "" ]; then
		# 게임별 선택 코어 cfg 만들기
		echo "$GAME_DEFAULT" > "$RUNCOMMAND_PATH/defaultGameCore/$EMULATOR/$ROM_TINY.cfg"
		sed -i "s/[\]//g" "$RUNCOMMAND_PATH/defaultGameCore/$EMULATOR/$ROM_TINY.cfg"
		echo "CREATE FILE : $RUNCOMMAND_PATH/defaultGameCore/$EMULATOR/$ROM_TINY.cfg" >> $LOG_FILE
		echo "SELECT GAME CORE : $GAME_DEFAULT" >> $LOG_FILE
	fi
}


function func_GameCoreRemove()
{
	echo "" >> $LOG_FILE
	echo "=== func_GameCoreRemove" >> $LOG_FILE
	
	rm -f "$RUNCOMMAND_PATH/defaultGameCore/$EMULATOR/$ROM_TINY.cfg"
	GAME_DEFAULT=""
}

# 런커맨드를 거치지 않고 바로 실행
function func_LaunchImmediately()
{
	echo "" >> $LOG_FILE
	echo "=== func_LaunchImmediately" >> $LOG_FILE
	
	func_LoadEmulatorOverClockMode
	func_LoadEmulatorCfg
	func_LoadGameCore
	func_LaunchGame
}

# 게임 실행
function func_LaunchGame()
{
	echo "" >> $LOG_FILE
	echo "=== func_LaunchGame" >> $LOG_FILE
	
	func_KillJoy2Key

	############################################### retroarch exec ###############################################################
	if [ "$GAME_DEFAULT" == "" ]; then
		CORE=$DEFAULT
	else
		CORE=$GAME_DEFAULT
	fi
	
	##### KILL joy2key.py ####################
	func_KillJoy2Key
	########################################

	$SCRIPT_PATH/runcommand_start.sh > /dev/null 2>&1

	# overclock setting
	if [ $OVERCLOCK_MODE == "PERFORMANCE" ]; then
		$OVERCLOCK_PATH/performance.sh
	elif [ $OVERCLOCK_MODE == "NORMAL" ]; then
		$OVERCLOCK_PATH/normal.sh
	else
		$OVERCLOCK_PATH/normal.sh
	fi

	## 32bit / 64bit 구분 ( 앞에 "32-" 가 붙으면 32비트 구동
	if [[ "$CORE" == *".so"* ]]; then
		if [[ "$CORE" == *"32-"* ]]; then
			CORE=${CORE:3}
			echo "RUNCOMMAND : $RETROARCH32_EXEC -L \"$CORE32_PATH/$CORE\" \"$ROM\"" >> $LOG_FILE

			if [ "$EMULATOR" == "dreamcast" ] || [ "$EMULATOR" == "atomiswave" ] || [ "$EMULATOR" == "naomi" ] || [ "$EMULATOR" == "psx" ]; then
				$RETROARCH32_EXEC -L "$CORE32_PATH/$CORE" < /dev/null "$ROM" > /dev/null 2>&1
			else
				$RETROARCH32_EXEC -L "$CORE32_PATH/$CORE" < /dev/null "$ROM" > /dev/null 2>&1
				#$RETROARCH32_EXEC -L "$CORE32_PATH/$CORE" "$ROM" > /dev/null 2>&1
			fi
		else
			echo "RUNCOMMAND : $RETROARCH_EXEC -L \"$CORE_PATH/$CORE\" \"$ROM\"" >> $LOG_FILE
			if [ "$EMULATOR" == "dreamcast" ] || [ "$EMULATOR" == "atomiswave" ] || [ "$EMULATOR" == "naomi" ] || [ "$EMULATOR" == "psx" ]; then
				$RETROARCH_EXEC -L "$CORE_PATH/$CORE" < /dev/null "$ROM" > /dev/null 2>&1
			else
				$RETROARCH_EXEC -L "$CORE_PATH/$CORE" < /dev/null "$ROM" > /dev/null 2>&1
				#$RETROARCH_EXEC -L "$CORE_PATH/$CORE" "$ROM" > /dev/null 2>&1
			fi
		fi
	else
		echo "RUNCOMMAND(no core) : $CORE \"$ROM\"" >> $LOG_FILE
		$CORE "$ROM" > /dev/null 2>&1
	fi

	# overclock init
	$OVERCLOCK_PATH/normal.sh

	$SCRIPT_PATH/runcommand_end.sh "$EMULATOR" "$ROM_FILENAME"
	#sudo killall ffplay > /dev/null 2>&1
	killall mpv > /dev/null 2>&1
	clear
	exit 0
}


# 런커맨드 코어선택 메인 함수
function func_CoreSelectMenu()
{
	echo "" >> $LOG_FILE
	echo "=== func_CoreSelectMenu==" >> $LOG_FILE	
	############################################### default core select ###############################################################


	## EMULATOR OVERCLOCK CFG LOAD #################################################
	func_LoadEmulatorOverClockMode

	## EMULATOR CORE CFG LOAD ###################################################
	func_LoadEmulatorCfg
	
	# 게임코어 읽어오기 - 없으면 디폴트
	func_LoadGameCore

	######################################## dialog menu ###########################################################
	dialog --clear --no-cancel --timeout 10  \
	--title "[ C O R E - S E L E C T ]" \
	--menu "UP/DOWN A-BUTTON! \n\
	OVERCLOCK : $OVERCLOCK_MODE \n\
	EMULATOR : $EMULATOR \n\
	ROM : $ROM_TINY \n\
	NO CONTROL : GAME CORE starts after 10 seconds" 25 100 60 \
	0 "-DEFAULT CORE( $DEFAULT )" \
	1 "-GAME CORE( $GAME_DEFAULT )" \
	2 "-GAME CORE REMOVE" \
	3 "-OVERCLOCK MODE( $OVERCLOCK_MODE )" \
	4 "Launch GAME" \
	EXIT "EXIT" 2>$RUNCOMMAND_PATH/menuitem > /dev/tty0

	############################################ select menu #######################################################
	menuitem=`cat $RUNCOMMAND_PATH/menuitem` 

	# make decsion 
	case $menuitem in
		0) func_DefaultCoreSelect;;
		1) func_GameCoreSelect;;
		2) func_GameCoreRemove;;
		3) func_OverClockSelect;;
		4) func_LaunchGame;;
		EXIT) func_KillJoy2Key;clear;exit 0;;
		*) func_LaunchGame;;
	esac	
}




##### Main Function ##################################################################

clear

#ffplay $LOADING_PATH/loading.mp4 -autoexit -t 3 -loglevel quiet > /dev/null 2>&1 &
mpv --fs $LOADING_PATH/loading.mp4 --input-default-bindings=no > /dev/null 2>&1 &
#"$RUNCOMMAND_PATH/
# joy2key enable - up down A-button
"$RUNCOMMAND_PATH/joy2key.py" "/dev/input/js0" kcub1 kcuf1 kcuu1 kcud1 0x0a 0x09 & 

echo "EMULATOR : $EMULATOR" > $LOG_FILE
echo "ROM_FULL_PATH : $ROM" >> $LOG_FILE 
echo "ROM : $ROM_TINY" >> $LOG_FILE
echo "ROM_FILENAME : $ROM_FILENAME" >> $LOG_FILE
echo "ROM_PATH : $ROM_PATH" >> $LOG_FILE
echo "ROM_PATH_REAL : $ROM_PATH_REAL" >> $LOG_FILE

if read -s -t $TIME -N 1 key; then
	while [ 1 ]; do
		#sudo killall ffplay > /dev/null 2>&1
		killall mpv > /dev/null 2>&1
		func_CoreSelectMenu
	done
else
	func_LaunchImmediately
fi

clear
#######################################################################################
