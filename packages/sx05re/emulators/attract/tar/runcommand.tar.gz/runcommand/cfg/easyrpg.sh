#!/bin/bash

bash "$1"
