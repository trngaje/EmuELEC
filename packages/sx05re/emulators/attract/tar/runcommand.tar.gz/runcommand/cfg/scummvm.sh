#!/bin/bash

cd /home/odroid/emulator/scummvm
./scummvm