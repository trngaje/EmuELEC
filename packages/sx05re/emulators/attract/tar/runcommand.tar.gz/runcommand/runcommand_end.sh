#!/bin/bash


# Screen / Records Path
SCREENSHOT_PATH="/storage/.config/retroarch/screenshots"
RECORDS_PATH="/storage/.config/retroarch/records"
SNAP_SELECT_PATH="/storage/runcommand"
SBX_SCREENSHOT_PATH="/storage/.config/retroarch/screenshot"

# roms Path
#ROM_PATH="/roms"
#ROM_PATH_REAL

echo "" >> $LOG_FILE
echo "=== runcommand_end" >> $LOG_FILE


# joy2key 프로세스 죽이기
function func_KillJoy2Key()
{
	JOY2KEY_PID=$(pgrep -f joy2key.py)
	sudo killall joy2key.py > /dev/null 2>&1
}

################################################################################
### SSHINBAYMAX Screenshots Move 
### ----------------------------------------------------------------------------
function SBXMove_ScreenshotAndRecord()
{
	if [ ! -d "$SBX_SCREENSHOT_PATH" ] ; then
		mkdir $SBX_SCREENSHOT_PATH
	fi
	mv $SCREENSHOT_PATH/* $SBX_SCREENSHOT_PATH
	mv $RECORDS_PATH/* $SBX_SCREENSHOT_PATH

	func_deleteRecord

}


######################################################################################################
# screenshot / records 옮기기 #
######################################################################################################

function func_snapSave()
{
	echo "- screenshot / records 옮기기" >> $LOG_FILE


	if [ "$(find /home/odroid/.config/retroarch/screenshots -maxdepth 1 -type f)" ]; then
		
		find $SCREENSHOT_PATH -type f | sort -n | while read entry
		do
			moveEntry="${entry:0:${#entry}-18}"
			mv "$entry" "$moveEntry.png" > /dev/null 2>&1
		done

		if [ ! -d "$ROM_PATH/snap" ] ; then
			mkdir $ROM_PATH/snap
		fi

		if [ "$EMULATOR" != "arcade" -a "$EMULATOR" != "mame" -a "$EMULATOR" != "fbneo" -a "$EMULATOR" != "mame-advmame" -a "$EMULATOR" != "hbmame" -a "$EMULATOR" != "fba" -a "$EMULATOR" != "fbn" ];then
			mv -vf $SCREENSHOT_PATH/* $ROM_PATH/snap >> $LOG_FILE
		else
			cp -vf $SCREENSHOT_PATH/* $ROM_PATH/snap >> $LOG_FILE
			mv -vf $SCREENSHOT_PATH/* /roms/arcade/snap >> $LOG_FILE
		fi
	fi
	
	
	if [ "$(find /storage/.config/retroarch/records -maxdepth 1 -type f)" ]; then
		
		find $RECORDS_PATH -type f | sort -n | while read recordsEntry
		do
			moveEntry="${recordsEntry:0:${#recordsEntry}-18}"
			mv "$recordsEntry" "$moveEntry.mkv" > /dev/null 2>&1
		done

		if [ ! -d "$ROM_PATH/snap" ] ; then
			mkdir $ROM_PATH/snap
		fi



		if [ $1 == "1" ]; then
		    	echo "FFMPEG FILE : ffmpeg -i "$RECORDS_PATH/$ROM_FILENAME.mkv" -vf \"transpose=2\"  -codec copy "$RECORDS_PATH/$ROM_FILENAME.mp4"" >> $LOG_FILE
			ffmpeg -i "$RECORDS_PATH/$ROM_FILENAME.mkv" -vf "transpose=2" -b:v 250k -maxrate 250k "$RECORDS_PATH/$ROM_FILENAME.mp4" > /dev/null 2>&1
		else
			echo "FFMPEG FILE : ffmpeg -i "$RECORDS_PATH/$ROM_FILENAME.mkv" -codec copy "$RECORDS_PATH/$ROM_FILENAME.mp4"" >> $LOG_FILE
			ffmpeg -i "$RECORDS_PATH/$ROM_FILENAME.mkv" -codec copy "$RECORDS_PATH/$ROM_FILENAME.mp4" > /dev/null 2>&1
		fi

		rm -rf $RECORDS_PATH/*.mkv
		if [ "$EMULATOR" != "arcade" -a "$EMULATOR" != "mame" -a "$EMULATOR" != "fbneo" -a "$EMULATOR" != "mame-advmame" -a "$EMULATOR" != "hbmame" -a "$EMULATOR" != "fba" -a "$EMULATOR" != "fbn" ];then
			echo "** NO ARCADE Copy mode..." >> $LOG_FILE
			cp -vf $RECORDS_PATH/* $ROM_PATH/snap >> $LOG_FILE
		else
			echo "** ARCADE Copy mode..." >> $LOG_FILE
			cp -vf $RECORDS_PATH/* $ROM_PATH/snap >> $LOG_FILE
			mv -vf $RECORDS_PATH/* /roms/arcade/snap >> $LOG_FILE
		fi
	fi
	######################################################################################################

	func_deleteRecord
}


function func_deleteRecord
{
	rm -rf $SCREENSHOT_PATH/*
	rm -rf $RECORDS_PATH/*
}




if [ "$(find /storage/.config/retroarch/screenshots -maxdepth 1 -type f)" ] || [ "$(find /home/odroid/.config/retroarch/records -maxdepth 1 -type f)" ]; then


	SNAP_IMAGE_FILENAME=""
	SNAP_MOVIE_FILENAME=""
	if [ "$(find /storage/.config/retroarch/screenshots -maxdepth 1 -type f)" ]; then
		SNAP_IMAGE_FILENAME="$2.png"
	fi

	if [ "$(find /storage/.config/retroarch/records -maxdepth 1 -type f)" ]; then
		SNAP_MOVE_FILENAME="$2.mp4"
	fi

	# joy2key enable - up down A-button
	"$SNAP_SELECT_PATH/joy2key.py" "/dev/input/js0" kcub1 kcuf1 kcuu1 kcud1 0x0a 0x09 & 

	####################################### dialog menu ###########################################################
	dialog --clear --no-cancel   \
	--title "[ S N A P - S A V E ]" \
	--menu "snap image : $SNAP_IMAGE_FILENAME\nsnap movie : $SNAP_MOVE_FILENAME" 10 100 0 \
	0 "DO NOT SAVE" \
	1 "SAVE SNAP : $SBX_SCREENSHOT_PATH" \
	2 "SAVE SNAP : /roms/$EMULATOR/snap" \
	3 "SAVE SNAP(Video Rotate) : /roms/$EMULATOR/snap" 2>$SNAP_SELECT_PATH/snapItem


	############################################ select menu #######################################################
	snapItem=`cat $SNAP_SELECT_PATH/snapItem` 

	if [ "$snapItem" == "1" ]; then
		SBXMove_ScreenshotAndRecord
	elif [ "$snapItem" == "2" ]; then
		func_snapSave 0
	elif [ "$snapItem" == "3" ]; then
		func_snapSave 1
	else
		func_deleteRecord
	fi

	func_KillJoy2Key
fi



# 세이브정보 저장하기
echo "" >> $LOG_FILE
echo "- 퀵 세이브 포인트 정보 저장하기" >> $LOG_FILE

# ls -t '/roms/gba/건스타 슈퍼 히어로즈 (한글)'.state*.png | while read line
sudo rm -f "$ROM_PATH_REAL/$ROM_FILENAME".saveInfo
sudo rm -f "$ROM_PATH_REAL/$ROM_FILENAME".state.auto

# 시간 순
ls -t "$ROM_PATH_REAL/$ROM_FILENAME".state*.png | while read line
do
	SAVEFILENAME=`basename "$line"`
	SAVESTATEFILE="${SAVEFILENAME%.*}"
	(printf "$line|" && ls -alh --time-style='+%Y-%m-%d %H:%M:%S' "$ROM_PATH_REAL/$SAVESTATEFILE" | awk '{print $6, $7"|"$5}') >> "$ROM_PATH_REAL/$ROM_FILENAME".saveInfo
done

# xboxdrv 종료
sudo killall xboxdrv > /dev/null 2>&1

# SDL2 rotate init
export SDL2_OGS_VERTICAL=

clear
