/storage/runcommand/coresetup $1 $2 "$3"


