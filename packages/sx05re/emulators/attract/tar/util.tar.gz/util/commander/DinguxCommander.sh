#!/bin/bash

export SDL_GAMECONTROLLERCONFIG_FILE="/home/odroid/util/commander/gamecontrollerdb.txt"

cd /home/odroid/util/commander
./DinguxCommander

export SDL_GAMECONTROLLERCONFIG_FILE="/home/odroid/util/SDL-GameControllerDB/gamecontrollerdb.txt"
