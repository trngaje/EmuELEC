#!/bin/bash

export SDL_GAMECONTROLLERCONFIG_FILE="/storage/util/commander/gamecontrollerdb.txt"

cd ~/util/commander
DinguxCommander_kor

export SDL_GAMECONTROLLERCONFIG_FILE="/storage/util/SDL-GameControllerDB/gamecontrollerdb.txt"
