#!/bin/bash

sudo killall drastic
sudo killall PPSSPPSDL
sudo killall OpenBOR
sudo killall openbor
sudo killall openmsx
sudo killall ffplay
sudo killall prince
sudo killall OpenJazz
sudo killall hcl
sudo killall devilutionx
sudo killall opentyrian
sudo killall pico8_dyn
sudo killall sm64.us.f3dex2e
sudo killall mupen64plus
sudo killall advmame
sudo killall scummvm
sudo killall mpv
sudo killall sdlpal
sudo killall sonic2013
sudo killall soniccd
sudo killall retrorun
sudo killall retrorun32
exit 0
