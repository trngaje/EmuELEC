#!/usr/bin/env python3

import evdev
import asyncio
import time
from subprocess import check_output
import os

pwrkey = evdev.InputDevice("/dev/input/event0")
odroidgosuper_joypad = evdev.InputDevice("/dev/input/event2")

brightness_path = "/sys/devices/platform/backlight/backlight/backlight/brightness"
max_brightness = int(open("/sys/devices/platform/backlight/backlight/backlight/max_brightness", "r").read())
volPer_python = "/home/odroid/util/globalkey/volume.py"

class Power:
    pwr = 116

class Joypad:
    l1 = 310
    r1 = 311
    l2 = 312
    r2 = 313

    up = 17
    down = 17
    left = 16
    right = 16

    tl2 = 312
    tr2 = 313
    f1 = 704
    f2 = 705
    select = 706
    start = 707
    f3 = 706
    f4 = 707
    hotkey = 705
    f5 = 708
    f6 = 709

    volDown = 710
    volUp = 711

class Vol:
    down = 114
    up = 115

def runcmd(cmd, *args, **kw):
    print(f">>> {cmd}")
    check_output(cmd, *args, **kw)

def brightness(direction):
    with open(brightness_path, "r+") as f:
        cur = int(f.read())
        if direction == 1:
                cur = cur + 5
        else:
                cur = cur - 5
        if cur <= 0:
                cur = 3
        if cur > 160:
                cur = 160
        f.seek(0, 0)
        f.write(f"{cur}")

async def handle_event(device):
    async for event in device.async_read_loop():
        if device.name == "rk8xx_pwrkey":
            keys = odroidgosuper_joypad.active_keys()
            if event.value == 1 and event.code == Power.pwr: # pwr
                if Joypad.r2 in keys:
                    os.system(" sudo kill -9 `ps -ef | grep emulationstation | awk '{print $2}'`")
                    runcmd("/bin/systemctl poweroff || true", shell=True)
                else:
                    runcmd("/bin/systemctl suspend || true", shell=True)

        elif device.name == "GO-Super Gamepad":
            keys = odroidgosuper_joypad.active_keys()
            print(keys)
            if Joypad.hotkey in keys:
                if event.code == Joypad.volDown and event.value == 1:
                    brightness(-1)
                elif event.code == Joypad.volUp and event.value == 1:
                    brightness(1)
                elif event.code == Joypad.f1 and event.value == 1:
                    os.system("/home/odroid/util/killgame/killgame.sh > /dev/null 2>\&1")
            elif event.value == 1 and Joypad.volDown in keys:
                runcmd("/usr/bin/amixer -q sset Playback 2%-", shell=True)
                runcmd("/home/odroid/util/globalkey/volume.py", shell=True)
            elif event.value == 1 and Joypad.volUp in keys:
                runcmd("/usr/bin/amixer -q sset Playback 2%+", shell=True)
                runcmd("/home/odroid/util/globalkey/volume.py", shell=True)
        elif device.name == "GO-Advance-RK Gamepad":
            keys = odroidgosuper_joypad.active_keys()
            print(keys)
            if Joypad.tr2 in keys:
                if event.type == 3: # EV_ABS
                    if event.code == 16: # left/right
                        if (event.value < 0):
                            runcmd("/usr/bin/amixer -q sset Playback 2%-", shell=True)
                            runcmd("/home/odroid/util/globalkey/volume.py", shell=True)
                        elif (event.value > 0):
                            runcmd("/usr/bin/amixer -q sset Playback 2%+", shell=True)
                            runcmd("/home/odroid/util/globalkey/volume.py", shell=True)
                    elif event.code == 17: # up/down
                        if (event.value < 0):
                            brightness(1)
                        elif (event.value > 0):
                            brightness(-1)
                elif event.type == 1: # EV_KEY
                    if event.value == 1:
                        if event.code == Joypad.l1:
                            runcmd("/usr/local/bin/perfnorm", shell=True)
                        elif event.code == Joypad.r1:
                            runcmd("/usr/local/bin/perfmax", shell=True)
        elif device.name == "GO-Advance Gamepad":
            keys = odroidgosuper_joypad.active_keys()
            print(keys)
            if Joypad.tr2 in keys:
                if event.type == 3: # EV_ABS
                    if event.code == 16: # left/right
                        if (event.value < 0):
                            runcmd("/usr/bin/amixer -q sset Playback 2%-", shell=True)
                            runcmd("/home/odroid/util/globalkey/volume.py", shell=True)
                        elif (event.value > 0):
                            runcmd("/usr/bin/amixer -q sset Playback 2%+", shell=True)
                            runcmd("/home/odroid/util/globalkey/volume.py", shell=True)
                    elif event.code == 17: # up/down
                        if (event.value < 0):
                            brightness(1)
                        elif (event.value > 0):
                            brightness(-1)
                elif event.type == 1: # EV_KEY
                    if event.value == 1:
                        if event.code == Joypad.l1:
                            runcmd("/usr/local/bin/perfnorm", shell=True)
                        elif event.code == Joypad.r1:
                            runcmd("/usr/local/bin/perfmax", shell=True)
        elif device.name == "GO-Advance Gamepad (rev 1.1)":
            keys = odroidgosuper_joypad.active_keys()
            print(keys)
            if Joypad.tr2 in keys:
                if event.type == 3: # EV_ABS
                    if event.code == 16: # left/right
                        if (event.value < 0):
                            runcmd("/usr/bin/amixer -q sset Playback 2%-", shell=True)
                            runcmd("/home/odroid/util/globalkey/volume.py", shell=True)
                        elif (event.value > 0):
                            runcmd("/usr/bin/amixer -q sset Playback 2%+", shell=True)
                            runcmd("/home/odroid/util/globalkey/volume.py", shell=True)
                    elif event.code == 17: # up/down
                        if (event.value < 0):
                            brightness(1)
                        elif (event.value > 0):
                            brightness(-1)
                elif event.type == 1: # EV_KEY
                    if event.value == 1:
                        if event.code == Joypad.l1:
                            runcmd("/usr/local/bin/perfnorm", shell=True)
                        elif event.code == Joypad.r1:
                            runcmd("/usr/local/bin/perfmax", shell=True)


        if event.code != 0:
            print(device.name, event)

def run():
    asyncio.ensure_future(handle_event(pwrkey))
    asyncio.ensure_future(handle_event(odroidgosuper_joypad))

    loop = asyncio.get_event_loop()
    loop.run_forever()

if __name__ == "__main__": # admire
    run()

