#!/usr/bin/env python

import commands
import os

data = commands.getoutput("amixer sget Playback | grep 'Right:'  | awk -F'[][db]' '{ print $4 }'" )
vol = float(data)
#print(vol)

volPer=0
if vol >= -6.75:
	volPer=100
if vol < -6.75 and vol >= -8.01:
	volPer=95
if vol < -8.01 and vol >= -9.36:
	volPer=90
if vol < -9.36 and vol >= -10.85:
	volPer=85
if vol < -10.85 and vol >= -12.34:
	volPer=80
if vol < -12.34 and vol >= -13.83:	
	volPer=75
if vol < -13.83 and vol >= -15.69:	
	volPer=70
if vol < -15.69 and vol >= -17.55:	
	volPer=65
if vol < -17.55 and vol >= -19.42:	
	volPer=60
if vol < -19.42 and vol >= -21.65:	
	volPer=55
if vol < -21.65 and vol >= -23.88:	
	volPer=50
if vol < -23.88 and vol >= -26.49:	
	volPer=45
if vol < -26.49 and vol >= -29.1:	
	volPer=40
if vol < -29.1 and vol >= -32.45:	
	volPer=35
if vol < -32.45 and vol >= -35.8:	
	volPer=30
if vol < -35.8 and vol >= -40.27:	
	volPer=25
if vol < -40.27 and vol >= -45.85:	
	volPer=20
if vol < -45.85 and vol >= -51.81:	
	volPer=15
if vol < -51.81 and vol >= -58.89:	
	volPer=10
if vol < -58.89 and vol >= -71.55:	
	volPer=5
if vol < -71.55 and vol >= -95:	
	volPer=0

#print(volPer)

f = open("/home/odroid/util/globalkey/volumePer", 'w')
f.write(str(volPer))
f.close()


