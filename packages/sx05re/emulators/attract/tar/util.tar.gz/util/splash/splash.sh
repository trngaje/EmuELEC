#!/bin/bash

BOOT_MOUNT_PATH="/usr/config/splash"
SPLASH_PATH="/storage/util/splash"
ES_SPLASH_PATH="/usr/config/emulationstation/resources"

# joy2key 프로세스 죽이기
function func_KillJoy2Key()
{
	JOY2KEY_PID=$(pgrep -f joy2key.py)
	kill -INT "$JOY2KEY_PID"
	#sudo killall joy2key.py > /dev/null 2>&1
}


# BOOT / ES 부팅로고 변경
function func_SplashSelectMenu()
{
	echo "=== func_SPlashSelectMenu=="

	CURRENT_LOGO=`cat $SPLASH_PATH/current_logo`

	LOGOS=(`ls $SPLASH_PATH/logo/*.png`)

	OPTIONS=()
	OPTIONS=("RANDOM" "RANDOM")
	for (( i = 0 ; i < ${#LOGOS[@]} ; i++ )) ; do
 		OPTIONS+=("$i"  `basename "${LOGOS[$i]%.*}"`)
	done
	OPTIONS+=("EXIT" "EXIT")
	#echo ${LOGOS[@]}

	######################################## dialog menu ###########################################################
	dialog --clear --no-cancel   \
	--title "[ B O O T / E S - L O G O - S E L E C T ]" \
	--menu "UP/DOWN A-BUTTON! \n\n\
	-- CURRENT LOGO : $CURRENT_LOGO\n\
	" 15 60 10 \
	"${OPTIONS[@]}" 2>$SPLASH_PATH/splashItem


	############################################ select menu #######################################################
	splashItem=`cat $SPLASH_PATH/splashItem` 

	if [ "$splashItem" != "EXIT" ]; then
		if [ "$splashItem" == "RANDOM" ]; then
			sed -i 's/RANDOM_ENABLE=False/RANDOM_ENABLE=True/g' $SPLASH_PATH/random_splash.sh
			$SPLASH_PATH/random_splash.sh
		else
			sed -i 's/RANDOM_ENABLE=True/RANDOM_ENABLE=False/g' $SPLASH_PATH/random_splash.sh
			#sudo cp -f ${LOGOS[$splashItem]} $ES_SPLASH_PATH/splash.png

			convert ${LOGOS[$splashItem]} -resize 1920x1080\! $ES_SPLASH_PATH/logo.png
			convert ${LOGOS[$splashItem]} -resize 1920x1080\! $BOOT_MOUNT_PATH/splash-1080.png

			echo `basename "${LOGOS[$splashItem]%.*}"` > $SPLASH_PATH/current_logo
		fi
	else
		func_KillJoy2Key
		exit 0
	fi
}




##### Main Function ##################################################################

clear



# joy2key enable - up down A-button
"$SPLASH_PATH/joy2key.py" "/dev/input/js0" kcub1 kcuf1 kcuu1 kcud1 0x0a 0x09 & 

while [ 1 ]; do
	func_SplashSelectMenu
done

clear
#######################################################################################
