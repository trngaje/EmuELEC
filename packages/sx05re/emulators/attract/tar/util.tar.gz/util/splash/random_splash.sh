#!/bin/bash

RANDOM_ENABLE=True
BOOT_MOUNT_PATH="/boot_real"
SPLASH_PATH="/home/odroid/util/splash"
ES_SPLASH_PATH="/home/odroid/emulationstation/resources"

PADNAME=`cat /sys/class/input/js0/device/name`
PADVENDOR=`cat /sys/class/input/js0/device/id/vendor`
PADPRODUCT=`cat /sys/class/input/js0/device/id/product`
PADVERSION=`cat /sys/class/input/js0/device/id/version`

function func_Random_Splash()
{
	RANDOM_LOGOS=(`ls $SPLASH_PATH/logo/*.png`)
	echo $1 > $SPLASH_PATH/current_index
	RANDOM_LOGO=${RANDOM_LOGOS[$1]}
	RANDOM_BOOT_LOGO=${RANDOM_LOGOS[$2]}

if [[ $PADNAME == "GO-Super Gamepad" ]]
then
        sudo convert $RANDOM_BOOT_LOGO -resize 854x480\! $ES_SPLASH_PATH/splash.png
        sudo convert $RANDOM_BOOT_LOGO -resize 854x480\! -rotate 270 -type truecolor $BOOT_MOUNT_PATH/logo.bmp
elif [[ $PADNAME == "OpenSimHardware OSH PB Controller" ]]
then
        sudo convert $RANDOM_BOOT_LOGO -resize 640x480\! $ES_SPLASH_PATH/splash.png
        sudo convert $RANDOM_BOOT_LOGO -resize 640x480\! -type truecolor $BOOT_MOUNT_PATH/logo.bmp
else
        sudo convert $RANDOM_BOOT_LOGO -resize 480x320\! $ES_SPLASH_PATH/splash.png
        sudo convert $RANDOM_BOOT_LOGO -resize 480x320\! -rotate 270 -type truecolor $BOOT_MOUNT_PATH/logo.bmp
fi

	echo `basename "${RANDOM_LOGO%.*}( random )"` > $SPLASH_PATH/current_logo
}


function func_Main()
{
	if [ "$RANDOM_ENABLE" == True ]; then
		CURRENT_INDEX=(`cat $SPLASH_PATH/current_index`)
		COUNT=`ls -l $SPLASH_PATH/logo/*.png | grep ^- | wc -l`
		if [ "$COUNT" == "0" ]; then
			exit 0
		fi
		RANDOM_VAL=$((RANDOM%$COUNT))
		RANDOM_BOOT_VAL=$((RANDOM%$COUNT))
		if [ "$RANDOM_VAL" != "$CURRENT_INDEX" ]; then
			func_Random_Splash $RANDOM_VAL $RANDOM_BOOT_VAL
		fi
	fi
}

func_Main

exit 0
