#!/bin/bash

RANDOM_ENABLE=True
BOOT_MOUNT_PATH="/storage/.config/splash"
SPLASH_PATH="/storage/util/splash"
ES_SPLASH_PATH="/usr/config/emulationstation/resources"

function func_Random_Splash()
{
	RANDOM_LOGOS=(`ls $SPLASH_PATH/logo/*.png`)
	echo $1 > $SPLASH_PATH/current_index
	RANDOM_LOGO=${RANDOM_LOGOS[$1]}
	RANDOM_BOOT_LOGO=${RANDOM_LOGOS[$2]}


    #convert $RANDOM_BOOT_LOGO -resize 1920x1080\! $ES_SPLASH_PATH/logo.png
    convert $RANDOM_BOOT_LOGO -resize 1920x1080\!  $BOOT_MOUNT_PATH/splash-1080.png


	echo `basename "${RANDOM_LOGO%.*}( random )"` > $SPLASH_PATH/current_logo
}


function func_Main()
{
	if [ "$RANDOM_ENABLE" == True ]; then
		CURRENT_INDEX=(`cat $SPLASH_PATH/current_index`)
		COUNT=`ls -l $SPLASH_PATH/logo/*.png | grep ^- | wc -l`
		if [ "$COUNT" == "0" ]; then
			exit 0
		fi
		RANDOM_VAL=$((RANDOM%$COUNT))
		RANDOM_BOOT_VAL=$((RANDOM%$COUNT))
		if [ "$RANDOM_VAL" != "$CURRENT_INDEX" ]; then
			func_Random_Splash $RANDOM_VAL $RANDOM_BOOT_VAL
		fi
	fi
}

func_Main

exit 0
