#!/bin/bash
./controllermap 0 > gamecontrollerdb.txt